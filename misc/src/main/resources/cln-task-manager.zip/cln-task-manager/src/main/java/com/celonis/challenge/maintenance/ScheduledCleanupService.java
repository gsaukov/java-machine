package com.celonis.challenge.maintenance;

public interface ScheduledCleanupService {

    void cleanupTasks();

}
