package com.celonis.challenge.model.countertask.entity;

public enum CounterTaskStatus {
    ACTIVE,
    RUNNING,
    STOPPED,
    FINISHED;
}
