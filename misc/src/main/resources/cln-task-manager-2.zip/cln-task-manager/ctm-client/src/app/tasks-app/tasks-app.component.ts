import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tasks-app',
  templateUrl: './tasks-app.component.html',
  styleUrls: ['./tasks-app.component.scss']
})
export class TasksAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
