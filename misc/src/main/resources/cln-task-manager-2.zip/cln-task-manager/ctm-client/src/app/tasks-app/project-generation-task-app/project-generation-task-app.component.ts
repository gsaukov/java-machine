import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-generation-task-app',
  templateUrl: './project-generation-task-app.component.html',
  styleUrls: ['./project-generation-task-app.component.scss']
})
export class ProjectGenerationTaskAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
